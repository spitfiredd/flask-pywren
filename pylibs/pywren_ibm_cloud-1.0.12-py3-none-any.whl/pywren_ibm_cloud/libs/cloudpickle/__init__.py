from pywren_ibm_cloud.libs.cloudpickle.cloudpickle import *

__version__ = '0.6.1'
